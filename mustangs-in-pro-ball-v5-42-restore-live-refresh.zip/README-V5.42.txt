V5.42 - Restore 30-minute live refresh

Upload:
  .github/workflows/live-refresh.yml

This workflow:
- runs every 30 minutes
- runs update_stats.py --mode live
- refreshes stats.json and today_schedule.json
- also saves players.json when a missing official player ID is discovered
- does NOT rewrite Mustangs Daily, transactions, or the article archive during the day

The existing nightly-stats.yml remains in place for the full daily publication.
